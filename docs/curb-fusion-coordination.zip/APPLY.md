# Apply coordination plan

GitHub publication was blocked by integration write permissions. From a clean checkout based on main at 7912cb6 (or a later compatible commit), run:

```sh
git switch -c docs/shared-build-plan
git apply --check /path/to/curb-fusion-coordination.patch
git apply /path/to/curb-fusion-coordination.patch
git add AGENTS.md README.md docs/SHARED_BUILD_PLAN.md docs/DATA_CONTRACT.md docs/PARTNER_HANDOFF_ORIGINAL.md agents/status/context-ui.md
git commit -m "docs: coordinate Curb Fusion agents and data contracts"
git push -u origin docs/shared-build-plan
```

Review and merge using your normal GitHub workflow. If apply-check fails, stop and reconcile the affected files; do not overwrite concurrent work. The README change is only an additive coordination pointer. The partner owns their own status file and must acknowledge the plan before overlapping work resumes. Application/data snapshots are inventoried, not included in this documentation-only package.
